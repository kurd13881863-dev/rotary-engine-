راهنمای روش ساده آپلود از گوشی

1) فایل Simulator-Rx-9-Android-APK-Builder.zip را در مخزن GitHub خود در ریشه (صفحه اصلی مخزن) آپلود کنید. ZIP را استخراج نکنید؛ خود فایل ZIP را آپلود کنید.
2) در مخزن GitHub گزینه Add file > Create new file را بزنید.
3) در نام فایل، دقیقاً بنویسید:
   .github/workflows/build-apk-from-zip.yml
4) فایل متنی build-apk-from-uploaded-zip.yml همراه این بسته را باز کنید، همه متن آن را کپی کرده و در ویرایشگر GitHub بچسبانید.
5) پایین صفحه Commit changes را بزنید.
6) از زبانه Actions، workflow با نام Build Simulator Rx-9 APK را باز کنید. اگر اجرا نشده، Run workflow را بزنید.
7) پس از موفقیت (علامت سبز)، وارد اجرای workflow شوید و پایین صفحه در بخش Artifacts روی Simulator-Rx-9-APK بزنید.
8) فایل artifact را دانلود و از حالت ZIP خارج کنید؛ app-debug.apk را روی گوشی نصب کنید.

نکته: ZIP پروژه باید در ریشه مخزن و با همین نام دقیق باشد. فایل workflow نیز باید در مسیر .github/workflows قرار بگیرد.
